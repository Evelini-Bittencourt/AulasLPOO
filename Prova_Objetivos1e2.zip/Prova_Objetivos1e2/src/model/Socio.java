package model;

public interface Socio {
    int getQuantidadeDeAcoes();
    double getValorDaAcao();
}
